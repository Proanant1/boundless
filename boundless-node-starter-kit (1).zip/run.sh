#!/bin/bash
source .env
echo "Starting Boundless node..."
node index.js >> logs.txt 2>&1