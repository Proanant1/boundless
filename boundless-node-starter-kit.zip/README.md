# 🛡️ Boundless Node Setup Guide — by @Proanant1

A complete guide for installing, running, and maintaining a **Boundless** Prover/Validator Node.

> ⚠️ This guide is written for educational/community use. Run nodes at your own discretion and risk.

## 📚 Table of Contents
- [Introduction](#introduction)
- [System Requirements](#system-requirements)
- [Pre-Requisites](#pre-requisites)
- [Automated Setup](#automated-setup)
- [Manual Setup](#manual-setup)
  - [Step 1: Update System](#step-1-update-system)
  - [Step 2: Install Dependencies](#step-2-install-dependencies)
  - [Step 3: Clone Boundless Repo](#step-3-clone-boundless-repo)
  - [Step 4: Configure Environment](#step-4-configure-environment)
  - [Step 5: Run Node](#step-5-run-node)
- [Updating Node](#updating-node)
- [Common Issues](#common-issues)
- [Tips & Resources](#tips--resources)

## 📖 Introduction

This guide helps you set up a **Boundless Node** from scratch using either **manual** steps or **auto scripts**, depending on your preference.

## 💻 System Requirements

| Component | Minimum | Recommended |
|----------|---------|-------------|
| CPU      | 2 cores | 4+ cores    |
| RAM      | 4 GB    | 8 GB        |
| Disk     | 50 GB SSD | 100+ GB SSD |
| OS       | Ubuntu 20.04 / 22.04 LTS | Ubuntu 22.04 LTS |

## ⚙️ Pre-Requisites

Ensure the following:
- VPS or local Ubuntu machine (with public IP)
- `git`, `curl`, `docker` installed
- SSH access (if VPS)
- Optional: `screen` or `tmux` for long sessions

## ⚡ Automated Setup

```bash
git clone https://github.com/Proanant1/boundless
cd boundless
chmod +x install.sh
./install.sh
```

## 🔧 Manual Setup

### Step 1: Update System

```bash
sudo apt update && sudo apt upgrade -y
```

### Step 2: Install Dependencies

```bash
sudo apt install git curl unzip -y
```

### Step 3: Clone Boundless Repo

```bash
git clone https://github.com/Proanant1/boundless
cd boundless
```

### Step 4: Configure Environment

```bash
cp .env.example .env
nano .env
# Add your PRIVATE_KEY, RPC_URL, etc.
```

### Step 5: Run Node

```bash
chmod +x run.sh
./run.sh
```

> Use `screen -S boundless` or `tmux` to keep it running in the background.

## 🔄 Updating Node

```bash
cd ~/boundless
git pull origin main
./run.sh
```

## 🛠️ Common Issues

| Issue | Fix |
|-------|-----|
| Port already in use | Change port in `.env` |
| Permission denied | `chmod +x run.sh` |
| Env not loading | Double-check `.env` format |
| Node not syncing | Check RPC node or internet connection |

## 📌 Tips & Resources

- Use a **reliable VPS** (Hetzner, Contabo, Oracle, etc.)
- Monitor logs: `tail -f logs.txt`
- Join Boundless Discord for updates and help
- Keep `.env` secure — never share private keys

## 🙌 Contributing

Feel free to fork this repo and suggest changes or improvements.