#!/bin/bash
sudo apt update && sudo apt upgrade -y
sudo apt install git curl unzip -y
git clone https://github.com/Proanant1/boundless.git
cd boundless
if [ ! -f .env ]; then
  cp .env.example .env
  echo "🔧 Edit your .env file before running the node."
fi
echo "✅ Installation complete. You can now run the node with ./run.sh"